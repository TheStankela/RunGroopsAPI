﻿namespace RunGroops.Domain.Enum
{
    public enum ClubCategory
    {
        RoadRunner = 1,
        Womens,
        City,
        Trail,
        Endurance
    }
}
