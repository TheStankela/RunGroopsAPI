﻿namespace RunGroops.Domain.Enum
{
    public enum UserCategory
    {
        Walker,
        Beginner,
        Intermediate,
        Athlete,
        FiveK,
        Marathoner,
        Ultra
    }
}
