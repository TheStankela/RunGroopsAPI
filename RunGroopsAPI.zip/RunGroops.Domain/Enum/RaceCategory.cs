﻿namespace RunGroops.Domain.Enum
{
    public enum RaceCategory
    {
        Marathon = 1,
        Ultra,
        FiveK,
        TenK,
        HalfMarathon
    }
}
