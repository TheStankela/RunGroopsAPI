﻿namespace RunGroops.Domain.Enum
{
    public class UserRoles
    {
        public const string Admin = "admin";
        public const string User = "user";
    }
}
